import { Component } from '@angular/core';

@Component({
  selector: 'app-mas-vendidos',
  standalone: true,
  imports: [],
  templateUrl: './mas-vendidos.component.html',
  styleUrl: './mas-vendidos.component.scss'
})
export class MasVendidosComponent {

}
